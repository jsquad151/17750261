﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2_v18
{
    class Map
    {
        private const int MAX_RANDOM_UNITS = 50;
        public const string FIELD_SYMBOL = ".";
        public string[,] grid = new string[20, 20];
        private List<Unit> unitsonMap = new List<Unit>();
        private int numberofUnitsOnMap = 0;

        ResourceBuilding heartsbuilding = new ResourceBuilding(0, 0, 1000, "Hearts", "C");
        ResourceBuilding spadesbuilding = new ResourceBuilding(19, 19, 1000, "Spades", "C");
        FactoryBuilding heartsfactory = new FactoryBuilding(19, 0, 1000, "Hearts", "F");
        FactoryBuilding spadesfactory = new FactoryBuilding(0, 19, 1000, "Spades", "F");

        public ResourceBuilding Heartsbuilding
        {
            get { return heartsbuilding; }
            set { heartsbuilding = value; }
        }

        public ResourceBuilding Spadesbuilding
        {
            get { return spadesbuilding; }
            set { spadesbuilding = value; }
        }

        public FactoryBuilding Heartsfactory
        {
            get { return heartsfactory; }
            set { heartsfactory = value; }
        }

        public FactoryBuilding Spadesfactory
        {
            get { return spadesfactory; }
            set { spadesfactory = value; }
        }

        public string[,] Grid
        {
            get
            {
                return grid;
            }
        }

        public List<Unit> UnitsOnMap
        {
            get
            {
                return unitsonMap;
            }
        }

        public void LoadFromList()
        {
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    grid[i, j] = FIELD_SYMBOL;
                }
            }

            int x, y;

            x = heartsbuilding.X;
            y = heartsbuilding.Y;
            grid[x, y] = heartsbuilding.Symbol;

            x = spadesbuilding.X;
            y = spadesbuilding.Y;
            grid[x, y] = spadesbuilding.Symbol;

            x = heartsfactory.X;
            y = heartsfactory.Y;
            grid[x, y] = heartsfactory.Symbol;

            x = spadesfactory.X;
            y = spadesfactory.Y;
            grid[x, y] = spadesfactory.Symbol;

            foreach (Unit u in UnitsOnMap)
            {
                x = u.X;
                y = u.Y;

                grid[x, y] = u.Symbol;
            }
        }

        public void populate()
        {
            Random rnd = new Random();
            int numberRandomUnits = rnd.Next(0, MAX_RANDOM_UNITS) + 1;
            int x, y, randomAttackRange;
            bool attackOption;
            string team;
            
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    grid[i, j] = FIELD_SYMBOL;
                }
            }

            x = heartsbuilding.X;
            y = heartsbuilding.Y;
            grid[x, y] = heartsbuilding.Symbol;

            x = spadesbuilding.X;
            y = spadesbuilding.Y;
            grid[x, y] = spadesbuilding.Symbol;

            x = heartsfactory.X;
            y = heartsfactory.Y;
            grid[x, y] = heartsfactory.Symbol;

            x = spadesfactory.X;
            y = spadesfactory.Y;
            grid[x, y] = spadesfactory.Symbol;

            for (int k = 1; k <= numberRandomUnits; k++)
            {
                do
                {
                    x = rnd.Next(0, 20);
                    y = rnd.Next(0, 20);
                } while (grid[x, y] != FIELD_SYMBOL);
                
                if (rnd.Next(1, 3) == 1)
                {
                    attackOption = rnd.Next(0, 2) == 1 ? true : false;        
                    team = rnd.Next(0, 2) == 1 ? "Hearts" : "Spades";
                    Unit tmp = new MeleeUnit("Swordsman", x, y, 100, -1, attackOption, 1, team, "M");
                    unitsonMap.Add(tmp);


                    grid[x, y] = tmp.Symbol;
                    
                    numberofUnitsOnMap++;
                }
                else
                {
                    attackOption = rnd.Next(0, 2) == 1 ? true : false;
                    randomAttackRange = rnd.Next(1, 20);
                    team = rnd.Next(0, 2) == 1 ? "Hearts" : "Spades";
                    Unit tmp = new RangedUnit("Ranger", x, y, 100, -1, attackOption, randomAttackRange, team, "R");
                    unitsonMap.Add(tmp);

                    grid[x, y] = unitsonMap[numberofUnitsOnMap].Symbol;
                    
                    numberofUnitsOnMap++;
                }
            }

        }

        private void moveOnMap(Unit u, int newX, int newY)
        {
            grid[u.X, u.Y] = FIELD_SYMBOL;
            grid[newX, newY] = u.Symbol;
        }

        public void update(Unit u, int newX, int newY)
        {
            if ((newX >= 0 && newX < 20) && (newY >= 0 && newY < 20))
            {
                moveOnMap(u, newX, newY);
                u.move(newX, newY);
            }
        }

        public void checkHealth()
        {
            for (int i = 0; i < numberofUnitsOnMap; i++)
            {
                if (!unitsonMap[i].isAlive())
                {
                    grid[unitsonMap[i].X, unitsonMap[i].Y] = FIELD_SYMBOL;  
                    unitsonMap.RemoveAt(i);      
                    numberofUnitsOnMap--;
                }
            }
        }


    }
}
