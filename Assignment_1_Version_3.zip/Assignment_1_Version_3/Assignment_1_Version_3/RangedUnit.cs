﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2_v18
{
    class RangedUnit : Unit
    {
        private const int Damage = 2;
        public RangedUnit(string name, int x, int y, int health, int speed, bool attack, int attackRange, string faction, string symbol) 
            : base(name, x, y, health, speed, attack, attackRange, faction, symbol)
        {
        }

        public override void move(int x, int y)
        {
            if (x >= 0 && x < 20)
                X = x;
            if (y >= 0 && y < 20)
                Y = y;
        }

        public override void combat(Unit enemy)
        {
            if (this.isWithinAttackRange(enemy))
            {
                enemy.Health -= Damage;
            }
        }

        public override bool isWithinAttackRange(Unit enemy)
        {
            if ((Math.Abs(this.X - enemy.X) <= this.AttackRange) || (Math.Abs(this.X - enemy.X) <= this.AttackRange))
                return true;
            else
                return false;
        }

        public override Unit nearestUnit(List<Unit> list)
        {
            Unit closest = null;
            int attackRangeX, attackRangeY;
            int shortestRange = 3000;

            foreach (Unit u in list)
            {
                attackRangeX = Math.Abs(this.X - u.X);
                attackRangeY = Math.Abs(this.Y - u.Y);

                if (attackRangeX < shortestRange)
                {
                    shortestRange = attackRangeX;
                    closest = u;
                }
                if (attackRangeY < shortestRange)
                {
                    shortestRange = attackRangeY;
                    closest = u;
                }
            }
            return closest;
        }
        public override bool isAlive()
        {
            if (this.Health <= 0)
                return false;
            else
                return true;
        }

        public override string toString()
        {
            string output = "x : " + X + Environment.NewLine
                + "y : " + Y + Environment.NewLine
                + "Health : " + Health + Environment.NewLine
                + "Speed : " + Speed + Environment.NewLine
                + "Attack : " + (Attack ? "Yes" : "No") + Environment.NewLine
                + "Attack Range : " + AttackRange + Environment.NewLine
                + "Faction : " + Faction + Environment.NewLine
                + "Symbol : " + Symbol + Environment.NewLine
                + "Name : " + Name + Environment.NewLine;
            return output;

        }
    }
}
