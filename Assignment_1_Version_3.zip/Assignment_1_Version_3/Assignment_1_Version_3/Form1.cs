﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Assignment_2_v18
{
    public partial class frmSimulation : Form
    {
        GameEngine engine = new GameEngine();
        

        public frmSimulation()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            SimTimer.Enabled = false;
        }

        private void btnStart_Click(object sender, EventArgs e)
        {
            btnPause.Enabled = true;
            btnStart.Enabled = false;
            SimTimer.Enabled = true;
        }

        private void SimTimer_Tick(object sender, EventArgs e)
        {
            lblTimer.Text = System.DateTime.Now.ToLongTimeString();


            engine.start();
            
            engine.map.Heartsbuilding.GenerateResources();
            lblHeartsResources.Text = "Hearts : " + Convert.ToString(engine.map.Heartsbuilding.remaining) + " Coins";

            engine.map.Spadesbuilding.GenerateResources();
            lblSpadesResources.Text = "Spades : " + Convert.ToString(engine.map.Spadesbuilding.remaining) + " Coins";
            
            lblMap.Text = "";
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    lblMap.Text += engine.map.grid[i, j] + " ";
                }
                lblMap.Text += "\n";
            }

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Are you sure you want to leave?", "Exit Game", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
                Application.Exit();
        }

        private void btnPause_Click(object sender, EventArgs e)
        {
            btnPause.Enabled = false;
            btnStart.Enabled = true;
            SimTimer.Enabled = false;
        }

        private void lblMap_Click(object sender, EventArgs e)
        {
            int mouseX = MousePosition.X;
            int mouseY = MousePosition.Y;

            int formX = this.Location.X;
            int formY = this.Location.Y;

            int y = (mouseX - formX - 39 - 6) / 15;
            int x = (mouseY - formY - 70 - 1) / 15;

            txtDisplay.Text = "";
            foreach (Unit u in engine.map.UnitsOnMap)
            {
                if (u.X == x && u.Y == y)
                {
                    txtDisplay.Text += u.toString();
                }
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            engine.SaveGame();
        }

        private void btnRead_Click(object sender, EventArgs e)
        {
            engine.LoadGame();
            engine.map.LoadFromList();
            lblMap.Text = "";
            for (int i = 0; i < 20; i++)
            {
                for (int j = 0; j < 20; j++)
                {
                    lblMap.Text += engine.map.grid[i, j] + " ";
                }
                lblMap.Text += "\n";
            }
        }

        private void lblHeartsResources_Click(object sender, EventArgs e)
        {

        }
    }
}
