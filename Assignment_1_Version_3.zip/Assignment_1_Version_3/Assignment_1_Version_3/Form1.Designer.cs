﻿namespace Assignment_2_v18
{
    partial class frmSimulation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSimulation));
            this.btnStart = new System.Windows.Forms.Button();
            this.btnPause = new System.Windows.Forms.Button();
            this.SimTimer = new System.Windows.Forms.Timer(this.components);
            this.lblMap = new System.Windows.Forms.Label();
            this.lblTimer = new System.Windows.Forms.Label();
            this.btnExit = new System.Windows.Forms.Button();
            this.txtDisplay = new System.Windows.Forms.TextBox();
            this.lblHeartsResources = new System.Windows.Forms.Label();
            this.lblSpadesResources = new System.Windows.Forms.Label();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnRead = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnStart
            // 
            this.btnStart.Location = new System.Drawing.Point(571, 126);
            this.btnStart.Name = "btnStart";
            this.btnStart.Size = new System.Drawing.Size(75, 23);
            this.btnStart.TabIndex = 0;
            this.btnStart.Text = "&Start";
            this.btnStart.UseVisualStyleBackColor = true;
            this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
            // 
            // btnPause
            // 
            this.btnPause.Location = new System.Drawing.Point(571, 155);
            this.btnPause.Name = "btnPause";
            this.btnPause.Size = new System.Drawing.Size(75, 23);
            this.btnPause.TabIndex = 1;
            this.btnPause.Text = "&Pause";
            this.btnPause.UseVisualStyleBackColor = true;
            this.btnPause.Click += new System.EventHandler(this.btnPause_Click);
            // 
            // SimTimer
            // 
            this.SimTimer.Enabled = true;
            this.SimTimer.Interval = 1000;
            this.SimTimer.Tick += new System.EventHandler(this.SimTimer_Tick);
            // 
            // lblMap
            // 
            this.lblMap.AutoSize = true;
            this.lblMap.Font = new System.Drawing.Font("Courier New", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblMap.Location = new System.Drawing.Point(35, 45);
            this.lblMap.Name = "lblMap";
            this.lblMap.Size = new System.Drawing.Size(398, 360);
            this.lblMap.TabIndex = 2;
            this.lblMap.Text = resources.GetString("lblMap.Text");
            this.lblMap.Click += new System.EventHandler(this.lblMap_Click);
            // 
            // lblTimer
            // 
            this.lblTimer.AutoSize = true;
            this.lblTimer.Location = new System.Drawing.Point(568, 37);
            this.lblTimer.Name = "lblTimer";
            this.lblTimer.Size = new System.Drawing.Size(36, 13);
            this.lblTimer.TabIndex = 3;
            this.lblTimer.Text = "Time :";
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(571, 184);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(75, 23);
            this.btnExit.TabIndex = 4;
            this.btnExit.Text = "&Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // txtDisplay
            // 
            this.txtDisplay.Location = new System.Drawing.Point(559, 231);
            this.txtDisplay.Multiline = true;
            this.txtDisplay.Name = "txtDisplay";
            this.txtDisplay.Size = new System.Drawing.Size(171, 178);
            this.txtDisplay.TabIndex = 5;
            // 
            // lblHeartsResources
            // 
            this.lblHeartsResources.AutoSize = true;
            this.lblHeartsResources.Location = new System.Drawing.Point(568, 66);
            this.lblHeartsResources.Name = "lblHeartsResources";
            this.lblHeartsResources.Size = new System.Drawing.Size(88, 13);
            this.lblHeartsResources.TabIndex = 6;
            this.lblHeartsResources.Text = "Hearts : 30 Coins";
            this.lblHeartsResources.Click += new System.EventHandler(this.lblHeartsResources_Click);
            // 
            // lblSpadesResources
            // 
            this.lblSpadesResources.AutoSize = true;
            this.lblSpadesResources.Location = new System.Drawing.Point(568, 79);
            this.lblSpadesResources.Name = "lblSpadesResources";
            this.lblSpadesResources.Size = new System.Drawing.Size(93, 13);
            this.lblSpadesResources.TabIndex = 7;
            this.lblSpadesResources.Text = "Spades : 30 Coins";
            // 
            // btnSave
            // 
            this.btnSave.Location = new System.Drawing.Point(653, 126);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(75, 23);
            this.btnSave.TabIndex = 8;
            this.btnSave.Text = "S&ave";
            this.btnSave.UseVisualStyleBackColor = true;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            // 
            // btnRead
            // 
            this.btnRead.Location = new System.Drawing.Point(653, 155);
            this.btnRead.Name = "btnRead";
            this.btnRead.Size = new System.Drawing.Size(75, 23);
            this.btnRead.TabIndex = 9;
            this.btnRead.Text = "&Read";
            this.btnRead.UseVisualStyleBackColor = true;
            this.btnRead.Click += new System.EventHandler(this.btnRead_Click);
            // 
            // frmSimulation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(788, 466);
            this.Controls.Add(this.btnRead);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.lblSpadesResources);
            this.Controls.Add(this.lblHeartsResources);
            this.Controls.Add(this.txtDisplay);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lblTimer);
            this.Controls.Add(this.lblMap);
            this.Controls.Add(this.btnPause);
            this.Controls.Add(this.btnStart);
            this.Name = "frmSimulation";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Combat Simulation";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnStart;
        private System.Windows.Forms.Button btnPause;
        private System.Windows.Forms.Timer SimTimer;
        private System.Windows.Forms.Label lblMap;
        private System.Windows.Forms.Label lblTimer;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox txtDisplay;
        private System.Windows.Forms.Label lblHeartsResources;
        private System.Windows.Forms.Label lblSpadesResources;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnRead;
    }
}

