﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2_v18
{
    class FactoryBuilding : Building
    {

        private int produceUnits;
        private int gameTicksPerProductions;
        private int spawnX, spawnY;
        

        public FactoryBuilding(int x, int y, int health, string faction, string symbol) : base(x, y, health, faction, symbol)
        {
        }
        
        public Unit SpawnNew(ResourceBuilding CallRB)
        {
            bool attackOption;
            string team;
            int randomAttackRange;
            int rndX, rndY;

            Random rndPoints = new Random();
            
            if (CallRB.remaining >= ResourceBuilding.cost)
            {
                CallRB.remaining = CallRB.remaining - ResourceBuilding.cost;
                Random rndSpawn = new Random();

                rndX = rndPoints.Next(1, 18);
                rndY = rndPoints.Next(1, 18);

                if (rndSpawn.Next(0, 2) == 0)
                {
                    attackOption = rndSpawn.Next(0, 2) == 1 ? true : false;
                    team = rndSpawn.Next(0, 2) == 1 ? "Hearts" : "Spades";
                    Unit SpawnM = new MeleeUnit("Swordsman", rndX, rndY, 100, -1, attackOption, 1, team, "M");
                    return SpawnM;
                }
                else
                {
                    attackOption = rndSpawn.Next(0, 2) == 1 ? true : false;
                    randomAttackRange = rndSpawn.Next(1, 20);
                    team = rndSpawn.Next(0, 2) == 1 ? "Hearts" : "Spades";
                    Unit SpawnR = new RangedUnit("Ranger",rndX, rndY, 100, -1, attackOption, randomAttackRange, team, "R");
                    return SpawnR;
                }
            }
            
            else
            {
                return null;
            }
        }

        public override bool isAlive()
        {
            if (this.Health <= 0)
                return false;
            else
                return true;
        }

        public override string toString()
        {
            string output = "x : " + X + Environment.NewLine
                + "y : " + Y + Environment.NewLine
                + "Health : " + Health + Environment.NewLine
                + "Faction : " + Faction + Environment.NewLine
                + "Symbol : " + Symbol + Environment.NewLine;
            return output;
        }
    }
}
