﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Assignment_2_v18
{
    class ResourceBuilding : Building
    {
        public const string resourcetype = "Coins";
        public const int resourceRecieved = 30;
        public int remaining = 0;
        public const int cost = 100;

        public ResourceBuilding(int x, int y, int health, string faction, string symbol) : base(x, y, health, faction, symbol)
        {
        }
        

        public int GenerateResources()
        {
            remaining = remaining + resourceRecieved;
            return remaining;
        }

        public int ConsumeResources()
        {
            remaining = remaining - cost;
            return remaining;
        }

        public override bool isAlive()
        {
            if (this.Health <= 0)
                return false;
            else
                return true;
        }

        public override string toString()
        {
            string output = "x : " + X + Environment.NewLine
                + "y : " + Y + Environment.NewLine
                + "Health : " + Health + Environment.NewLine
                + "Faction : " + Faction + Environment.NewLine
                + "Symbol : " + Symbol + Environment.NewLine;
            return output;
        }
    }
}
