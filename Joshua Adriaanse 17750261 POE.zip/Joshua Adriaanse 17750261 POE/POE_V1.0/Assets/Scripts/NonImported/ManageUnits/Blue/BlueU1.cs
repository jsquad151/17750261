﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BlueU1 : MonoBehaviour
{

    public GameObject RedAttackee;
    private Vector3 basePosition;
    private float dist;
    private float Speed = 1f;
    private int unitChoice;


    public void Awake()
    {
        unitChoice = Random.Range(1, 5);
        RedAttackee = GameObject.Find("Red_Unit 0" + unitChoice.ToString());
        basePosition = transform.position;
    }

    private void MoveController()
    {
        dist = Vector3.Distance(RedAttackee.transform.position, transform.position);

        if (dist < 400 & dist >= 0)
        {
            transform.LookAt(RedAttackee.transform);
            transform.position = Vector3.MoveTowards(transform.position, RedAttackee.transform.position, Speed * Time.deltaTime);
        }
        else if (dist < 0)
        {
            transform.LookAt(basePosition);
            transform.position = Vector3.MoveTowards(transform.position, basePosition, Speed * Time.deltaTime);
        }

    }

    // Update is called once per frame
    void Update()
    {
        MoveController();
    }
}

