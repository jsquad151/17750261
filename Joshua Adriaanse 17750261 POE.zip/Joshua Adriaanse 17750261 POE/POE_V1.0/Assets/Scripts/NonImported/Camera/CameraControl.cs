﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraControl : MonoBehaviour {

    [SerializeField] private float ZSpeed = 0.2f * Time.deltaTime;
    [SerializeField] private float YSpeed = 0.2f * Time.deltaTime;

    [SerializeField] private float ZPlane = 15f;
    [SerializeField] private float XPlane = 10f;
    [SerializeField] private float YPlane = 13f;

    // Use this for initialization
    void Start () {
		
	}

    // Update is called once per frame
    void Update()
    {
        //Movement Section
        //Moving forwards and backwards
        if (Input.GetKey(KeyCode.W) && gameObject.transform.position.z < 3)
        {
            gameObject.transform.position += new Vector3(0, 0, ZSpeed);
        }
        if (Input.GetKey(KeyCode.S) && gameObject.transform.position.z > -ZPlane)
        {
            gameObject.transform.position += new Vector3(0, 0, -ZSpeed);
        }
        //Moving right and left
        if (Input.GetKey(KeyCode.D) && gameObject.transform.position.x < XPlane)
        {
            gameObject.transform.position += new Vector3(ZSpeed, 0, 0);
        }
        if (Input.GetKey(KeyCode.A) && gameObject.transform.position.x > -XPlane)
        {
            gameObject.transform.position += new Vector3(-ZSpeed, 0, 0);
        }
        //Moving up and down
        if (Input.GetKey(KeyCode.R) && gameObject.transform.position.y < YPlane)
        {
            gameObject.transform.position += new Vector3(0, YSpeed, 0);
        }
        if (Input.GetKey(KeyCode.F) && gameObject.transform.position.y > 1)
        {
            gameObject.transform.position += new Vector3(0, -YSpeed, 0);
        }
    }
}
